The dataset contains files pretraining to the Warcraft shortest path. 
We also use an inmem dataloader as the data should ideally fit all into memory!